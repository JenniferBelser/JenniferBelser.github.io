======== SYTLES ========

Navigation
background-color: black;

Navigation Anchors
color: #cccccc

Navigation Hover
color: #ffffff
background-color: #ff7401

======== INSTRUCTIONS ========

1) Apply the above styling

2) Apply the navigation hover using :hover

3) Display the <a> tags as inline-block elements

4) Add padding to the <a>

Bonus: figure out how to remove the space between the elements
